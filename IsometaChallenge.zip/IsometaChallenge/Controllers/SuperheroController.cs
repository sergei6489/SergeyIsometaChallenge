﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IsometaChallenge.Models;

namespace IsometaChallenge.Controllers
{
    public class SuperheroController : Controller
    {
        readonly ISuperheroesRepository repository = new DbSuperheroesRepository();
        // GET: Superhero
        public ActionResult Index()
        {
            var heroes = AutoMapper.Mapper.Map<IEnumerable<Superhero>, IEnumerable<SuperheroViewModel>>(repository.GetAll());
            return View(heroes);
        }

        // GET: Superhero/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Superhero/Create
        [HttpPost]
        public ActionResult Create(SuperheroViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var hero = AutoMapper.Mapper.Map<SuperheroViewModel, Superhero>(model);
                    repository.Add(hero);
                    return RedirectToAction("Index");
                }
            }
            catch(Exception e)
            {
                ModelState.AddModelError(string.Empty, "Unable to save changes.");
            }
            return View(model);
        }

        // GET: Superhero/Edit/5
        public ActionResult Edit(int id)
        {
            var model = AutoMapper.Mapper.Map<Superhero, SuperheroViewModel>(repository.GetById(id));
            return View(model);
        }

        // POST: Superhero/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, SuperheroViewModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    var hero = AutoMapper.Mapper.Map<SuperheroViewModel, Superhero>(model);
                    hero.SuperheroId = id;
                    repository.Update(hero);
                    return RedirectToAction("Index");
                }
            }
            catch (Exception e)
            {
                ModelState.AddModelError(string.Empty, "Unable to save changes.");
            }
            return View(model);
        }
    }
}

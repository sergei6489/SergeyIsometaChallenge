﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace IsometaChallenge.Models
{
    public interface ISuperheroesRepository
    {
        IEnumerable<Superhero> GetAll();
        void Add(Superhero model);
        void Update(Superhero model);
        Superhero GetById(int id);
    }

    public class DbSuperheroesRepository : ISuperheroesRepository
    {
        public IEnumerable<Superhero> GetAll()
        {
            using (var db = new UniverseContext())
            {
                return db.Superheroes.ToList();
            }
        }

        public void Add(Superhero model)
        {
            using (var db = new UniverseContext())
            {
                db.Superheroes.Add(model);
                db.SaveChanges();
            }
        }

        public void Update(Superhero model)
        {
            using (var db = new UniverseContext())
            {
                db.Entry(model).State = EntityState.Modified;
                db.SaveChanges();
            }
        }

        public Superhero GetById(int id)
        {
            using (var db = new UniverseContext())
            {
                return db.Superheroes.Find(id);
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace IsometaChallenge.Models
{
    public class UniverseContext : DbContext
    {
        public DbSet<Superhero> Superheroes { get; set; }
        public DbSet<Team> Teams { get; set; }
    }
}
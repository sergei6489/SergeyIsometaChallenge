﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IsometaChallenge.Models
{
    public class Superhero
    {
        public int SuperheroId { get; set; }
        public string Name { get; set; }
        public string Superpower { get; set; }
        public string Weakness { get; set; }
        public int? TeamId { get; set; }
        public virtual Team Team { get; set; }
    }
}